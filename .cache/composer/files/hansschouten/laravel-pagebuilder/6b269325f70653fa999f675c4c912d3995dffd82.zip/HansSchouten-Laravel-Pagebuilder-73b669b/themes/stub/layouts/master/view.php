<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?= $page->get('title') ?></title>
    <link rel="stylesheet" href="<?= phpb_theme_asset('css/style.css') ?>" />
</head>
<body>

<?= $body ?>

</body>
</html>
