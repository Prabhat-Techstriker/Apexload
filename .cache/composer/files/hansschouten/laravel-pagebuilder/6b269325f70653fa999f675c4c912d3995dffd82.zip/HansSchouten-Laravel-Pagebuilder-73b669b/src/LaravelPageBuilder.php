<?php

namespace HansSchouten\LaravelPageBuilder;

use PHPageBuilder\PHPageBuilder;

class LaravelPageBuilder extends PHPageBuilder
{
}
