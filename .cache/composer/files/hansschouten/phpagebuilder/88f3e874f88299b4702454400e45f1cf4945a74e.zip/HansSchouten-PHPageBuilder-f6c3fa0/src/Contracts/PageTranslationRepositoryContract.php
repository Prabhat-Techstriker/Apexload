<?php

namespace PHPageBuilder\Contracts;

interface PageTranslationRepositoryContract
{
}
