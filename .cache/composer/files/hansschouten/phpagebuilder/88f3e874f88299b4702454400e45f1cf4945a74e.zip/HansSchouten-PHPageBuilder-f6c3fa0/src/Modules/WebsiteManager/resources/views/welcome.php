<div id="welcome-page">

    <h1 class="text-center">Welcome to PHPageBuilder</h1>

    <div class="text-center intro-links">
        <a href="<?= phpb_url('website_manager') ?>">Get started</a>
        <a href="https://github.com/HansSchouten/PHPageBuilder"><i class="fab fa-github"></i> Visit GitHub</a>
    </div>

</div>
